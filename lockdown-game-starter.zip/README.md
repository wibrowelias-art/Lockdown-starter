# Lockdown (working title)

A first-person, choice-driven school-lockdown story game. You are a student in
a Biology final when the school goes into lockdown. A friend is hiding alone,
someone knocks at the door, and you have to decide whether to open it.

- Tense thriller with real consequences, 4-5 endings.
- The attacker is never shown. No gore, no weapons, no player violence.
- Step 1: small browser demo (Three.js, low-poly) to test the idea.
- Step 2: realistic Unreal Engine 5.7 version, only if the demo works.

See `DESIGN.md` for the decisions and `PROMPT.md` for the Claude Code build prompt.
All characters, script and art must be original.
